# Projeto Mini Portfólio

Um projeto para a criação de um mini portfólio pra desenvolvedores iniciantes, com informações pessoais e links de redes sociais.

#

# Font family para utilização

- Family: [VT323](https://fonts.googleapis.com/css2?family=VT323)

# Linguagens

- HTML
- CSS
- JS
